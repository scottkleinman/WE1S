$(function () {
    $(".topic-link").mouseup(function () {return false;});
});
